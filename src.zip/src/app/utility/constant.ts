export const AppConstant= [
{empid:'1' ,empname:'Ravi', emprole :'CEO'},
{empid:'2' ,empname:'Barath', emprole :'Manager'},
{empid:'3' ,empname:'Mani', emprole :'.Net'},
{empid:'4' ,empname:'Venkat', emprole :'UI'},
{empid:'5' ,empname:'Gobu', emprole :'Devops'}
];


