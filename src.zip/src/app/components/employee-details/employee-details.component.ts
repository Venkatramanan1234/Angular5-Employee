import { Component, OnInit } from '@angular/core';
import { AppConstant } from '../../utility/constant'

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {
  items = AppConstant;
  constructor() { 
  }

  ngOnInit() {
  }

}
